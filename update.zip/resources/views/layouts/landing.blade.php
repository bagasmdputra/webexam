
<!doctype html>
<html lang="{{ config('landing.locale') }}">


          @yield('content')

</html>
