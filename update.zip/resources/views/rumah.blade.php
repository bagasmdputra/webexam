@extends('layouts.landing')

@section('content')
  <div class="welcome">
    <div class="welcome-left"></div>

    <div class="welcome-right">
      <div class="register-form">

      </div>
    </div>
  </div>
@endsection
