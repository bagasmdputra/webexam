<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class Examination_package extends Model
{
    public $timestamps = false;
}
