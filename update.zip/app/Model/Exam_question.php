<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class Exam_question extends Model
{
    public $timestamps = false;
}
