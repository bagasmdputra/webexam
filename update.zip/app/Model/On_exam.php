<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class On_exam extends Model
{
    public $timestamps = false;
}
